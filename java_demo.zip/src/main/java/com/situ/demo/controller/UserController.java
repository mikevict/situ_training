package com.situ.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.situ.demo.entity.User;
import com.situ.demo.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	/**
	 * 显示添加页面
	 * 访问/add时进入下面的方法
	 */
	@GetMapping("/add")
	public String add() {
		return "add";
	}
	/**
	 * 处理添加操作
	 * Post
	 */
	@PostMapping("/add")
	public String add(User user,Model model) {
		int code = userService.add(user);
		if(code > 0) {
			model.addAttribute("msg","添加成功");
		}else {
			
			model.addAttribute("msg","添加失败");
		}
		return "add";
		
	}
}
