package com.situ.demo.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller//1.添加Controller注解
/*
 * 作用：
 * 1）将当前类，放到Spring的容器中,IoC 控制反转,容器，整合，方便
 * 2）语义，这是MVC三层架构中的C这一层，一个Controller控制器
 */
public class IndexController {
	//3.给index方法添加路径的映射通常使用注解，RequestMapping ,GetMapping,PostMapping
	@RequestMapping("/")
//	只需要写8080后面的/
	// 2.定义一个方法来处理浏览器的访问，处理http://localhost:8000/路径的访问
	public String index() {
		return "index";	
		// 4.提供一个视图名，就会从templates文件夹下找到index.html作为页面
	}
//	5.在templates文件夹下创建一个index.html文件,templates上右键->new->other 
//	在弹出页中输入html，找到并选中html file 点击next
//	输入index.html 完成创建
}
