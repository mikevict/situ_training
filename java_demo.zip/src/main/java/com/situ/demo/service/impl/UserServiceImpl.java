package com.situ.demo.service.impl;

import javax.swing.Spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.situ.demo.entity.User;
import com.situ.demo.mapper.UserMapper;
import com.situ.demo.service.UserService;

@Service


public class UserServiceImpl implements UserService{
	@Autowired
	private UserMapper userMapper;
//	Spring 中的自动注解
	@Override
	public int add(User user) {
		// TODO Auto-generated method stub
		return userMapper.insert(user);
	}

}
