package com.situ.demo.service;

import com.situ.demo.entity.User;

public interface UserService {

	/**
	 * *添加用户
	 * 
	 * @param user
	 * @return
	 */
	int add(User user);
}
