package com.situ.demo.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

// 创建一个实体类与数据库对应
// 使用lombok的注解快速创建相关的方法

@Data	//自动添加get和set方法
@ToString //自动生成toString方法
@NoArgsConstructor // 自动生成无参构造方法
public class User {
	// 定义4个属性与数据表的字段对应
	private Integer id;
	private String username;
	private String password;
	private String realname;
	
	//为所有的属性添加get和set方法
	
	
	

}
