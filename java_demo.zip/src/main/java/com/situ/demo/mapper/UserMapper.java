package com.situ.demo.mapper;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;

import com.situ.demo.entity.User;

@Mapper
public interface UserMapper {
	/*
	 * 添加一条记录
	 */
	@Insert("insert into user (username, password) value(#{username},#{password})")
	int insert(User user);
}
