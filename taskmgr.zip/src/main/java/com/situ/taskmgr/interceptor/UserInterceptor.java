package com.situ.taskmgr.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

import com.situ.taskmgr.entity.User;

/**
 * 
 * @author 王浩
 * 登录拦截器
 * 如果用户登陆了，放行，可以进入相应的页面
 * 如果用户没有登陆，拦截，跳转到登陆页面
 */

@Component // 将拦截器放到Spring容器中，用Autowired取
public class UserInterceptor implements HandlerInterceptor{
	
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// 判断用户是否登录，登录信息保存在Session中的
		// 获取Session对象
		HttpSession session = request.getSession();
		// 获取当前登录的对象，getAttribute默认返回值为object类型
		User user = (User) session.getAttribute("user");
		
		if(user == null) {
			// 跳转到登录页面
			response.sendRedirect("/user/login");
			// 拦截
			return  false;
		}
		// 放行
		return true;
	}
	

}
