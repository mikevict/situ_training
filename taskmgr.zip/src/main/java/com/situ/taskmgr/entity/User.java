package com.situ.taskmgr.entity;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

/**
 * 
 * @author 王浩
 * 实体类要求 
 * 1. 类名与数据库表明一致
 * 2. 实体类的属性要与数据表的字段保持一致
 * 		1）名字要一致，各自遵循命名规范，java小驼峰，数据库下划线
 * 		2）数据类型要匹配，实体类的属性不要使用基本数据类型，而是使用java中的包装类，int只表示整数 Integer能表示 数和空值
 * 3.封装实体类
 * 		1）所有的属性私有化
 *      2）提供所有属性的get和set方法
 * 4.实体类应该拥有一个无参构造
 * 		一般情况下，为了打印方便，和应该提供toString方法
 */
@Data
@NoArgsConstructor
@ToString
public class User {
	private Integer id;
	private String username;
	private String password;
	private String phone;
	private String email;
	private String realname;
	private Integer role;
	private Integer status;
}
