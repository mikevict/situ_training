package com.situ.taskmgr.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.situ.taskmgr.entity.Join;
import com.situ.taskmgr.entity.Task;
import com.situ.taskmgr.mapper.JoinMapper;
import com.situ.taskmgr.mapper.TaskMapper;
import com.situ.taskmgr.service.TaskService;

@Service
public class TaskServiceImpl implements TaskService{
	
	//注入两个mapper层对象因为两个mapper都需要进行操作
	@Autowired
	private TaskMapper taskMapper;
	@Autowired
	private JoinMapper joinMapper;
	
	
	@Override
	public int add(Task task) {
		// 此处省略参数验证
		// 添加任务,任务与用户的关联
		// 插入任务task,任务的ID是由数据库自动生成的。
		int code = taskMapper.insert(task);
		
		// 插入任务与用户的关联join 这里需要任务ID，没有
		// 遍历所有的
		for(Join join : task.getJoins()) {
			join.setTaskId(task.getId());
			//将关系写入数据库
			code = joinMapper.insert(join);
		}
		
		return code;
	}

	@Override
	public int update(Task task) {
		// 修改任务的信息
		int code=taskMapper.update(task);
		
		// 修改任务的关联人员
		// 删除之前所有的关联
		code = joinMapper.deleteByTaskId(task.getId());
		// 重新添加关联人员
		for(Join join:task.getJoins()) {
			code = joinMapper.insert(join);
		}
		return code;
	}

	@Override
	public Task getById(Integer id) {
		return taskMapper.selectById(id);
	}

	@Override
	public PageInfo getByPage(Integer page, Integer limit) {
		// PageHelper
		PageHelper.startPage(page,limit);
		List<Task> list = taskMapper.select();
		return new PageInfo<>(list);
	}

	@Override
	public List<Task> getByWeek() {
		// 获取当天的时间
		Calendar calendar = Calendar.getInstance();//获取当前的时间，包括年月日十分秒
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		//清零 时 分 秒 毫秒
		// 获取2023-1-8 00:00:00.000
		
		// 获取这一周的周一
		calendar.setWeekDate(calendar.getWeekYear(), //这一周是第几年
				calendar.get(Calendar.WEEK_OF_YEAR)+
				(calendar.get(Calendar.DAY_OF_WEEK)==1?-1:0),// 这一年的第几周,如果是周日算到上一周
				2);//	这一周的第几天,周一是第二天
		Date start = calendar.getTime();
		
		// 获取下周的周一
		calendar.setWeekDate(calendar.getWeekYear(),
				 calendar.get(Calendar.WEEK_OF_YEAR)+1,
				2);
		Date end = calendar.getTime();
		return taskMapper.selectByDate(start, end);
	}

}
