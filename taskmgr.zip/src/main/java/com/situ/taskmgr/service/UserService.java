package com.situ.taskmgr.service;

import java.util.List;

import com.github.pagehelper.PageInfo;
import com.situ.taskmgr.entity.User;

/**
 * 
 * @author 王浩
 * 1. 根据业务功能需求，添加方法
 */
public interface UserService {
	/**
	 * 登录
	 * @param user 
	 */
	User login(User user) throws Exception;
	
	/**
	 * 添加
	 */
	int add(User user) throws Exception;
	
	/**
	 * 修改
	 */
	int edit(User user) throws Exception;
	
	/**
	 * 根据ID查询
	 */
	User getById(Integer id);
	
	/**
	 * 查询所有
	 */
	List<User> getAll();
	
	/**
	 * 分页查询 借助第三方插件 PageHelper
	 */
	PageInfo getByPage(Integer page,Integer limit);
	
	/**
	 * 修改密码的
	 * @param oldPassword
	 * @param newPassword
	 * @param rePassword
	 * @param id
	 * @return
	 * 
	 * 
	 * 
	 */
	
	int modifyPwd(String oldPassword, String newPassword, String rePassword,
			Integer id) throws Exception;
	
	
	
	
	
	
	
	
	
	
}
