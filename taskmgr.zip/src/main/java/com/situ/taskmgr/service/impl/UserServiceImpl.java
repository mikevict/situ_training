package com.situ.taskmgr.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.situ.taskmgr.entity.User;
import com.situ.taskmgr.mapper.UserMapper;
import com.situ.taskmgr.service.UserService;
import com.situ.taskmgr.util.MD5Util;

/**
 * 
 * @author 王浩
 * 1. 需要添加@Service注解
 * 2. 实现Service层的接口，类后面添加implements 接口
 * 3. 提娜佳接口中需要实现的方法，鼠标放到类名
 * 4. 使用@Autowired注解，来注入Mapper层对象，访问数据库
 * 5. 实现Service层的所有方法
 * 		1）验证参数的格式
 * 		2）逻辑的判断处理
 * 		3）访问数据库
 */
@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserMapper userMapper;
//	报空指针
	@Override
	public User login(User user) throws Exception {
		// 1.验证参数 账号和密码的格式
//		账号
		if(user.getUsername().length() < 3 || user.getUsername().length() > 16) {
//			账号的格式不对
			throw new Exception("账号必须是3~16位的字符串！");
		}
//		密码
		if(user.getPassword().length() < 3 ||
				user.getPassword().length() > 16) {
//			密码格式不对
			throw new Exception("密码必须是3~16位的字符串！");
		}
//		验证账号是否存在
		User sUser = userMapper.selectByUsername(user.getUsername());
		if(sUser == null) {
			throw new Exception("账号不存在!!!");
		}
//		明文密码进行MD5加密,md5Pwd 密文
		
		String md5Pwd = MD5Util.getMD5(user.getPassword());
		System.out.println(md5Pwd);
		
		if(!sUser.getPassword().equals(md5Pwd)) {
			throw new Exception("密码不正确");
		}
//		用户状态
		if(sUser.getStatus()==1) {
			throw new Exception("用户被禁用，请联系管理员!");
		}
//		返回数据库查出来的用户信息
		return sUser;
	}

	

	@Override
	public int add(User user) throws Exception {
		// 添加用户，用户在添加页面中输入账号，密码，邮箱，姓名，角色
		//		账号
		if(user.getUsername().length() < 3 || user.getUsername().length() > 16) {
//			账号的格式不对
			throw new Exception("账号必须是3~16位的字符串！");
		}
//		密码
		if(user.getPassword().length() < 3 ||
				user.getPassword().length() > 16) {
//			密码格式不对
			throw new Exception("密码必须是3~16位的字符串！");
		}
		
		// 电话
		if(user.getPhone().length() != 11) {
			throw new Exception("电话号码必须是11位的!");
		}
		// 邮箱
		if(user.getEmail().length() < 6||
				user.getEmail().length() > 64) {
			throw new Exception("邮箱格式不对!!");
		}
		//姓名
		if(user.getRealname().length() < 2||
				user.getRealname().length() > 16) {
			throw new Exception("姓名必须是2~16位的字符串!");		
		}
		//用户名是否重复
		User sUser = userMapper.selectByUsername(user.getUsername());
		if(sUser != null) {
			throw new Exception("账号已经存在!");
		}
		
		// 密码进行MD5加密
		user.setPassword(MD5Util.getMD5(user.getPassword()));
		// 写入数据库
		return userMapper.insert(user);
	}

	@Override
	public int edit(User user) throws Exception {		
		// 电话
		if(user.getPhone() != null && user.getPhone().length() != 11) {
			throw new Exception("电话号码必须是11位的!");
		}
		// 邮箱
		if(user.getEmail() != null && (user.getEmail().length() < 6||
				user.getEmail().length() > 64)) {
			throw new Exception("邮箱格式不对!!");
		}
		//姓名
		if(user.getRealname() != null && (user.getRealname().length() < 2||
				user.getRealname().length() > 16)) {
			throw new Exception("姓名必须是2~16位的字符串!");		
		}
		return userMapper.update(user);
	}

	@Override
	public User getById(Integer id) {
		
		return userMapper.selectById(id);
	}

	@Override
	public List<User> getAll() {
		return userMapper.select();
	}

	@Override
	public PageInfo getByPage(Integer page, Integer limit) {
		// 查询时分页，借助PageHelper,当前页码和页面大小
		PageHelper.startPage(page,limit);
		List<User> list = userMapper.select();// 变成分页查询，因为pagehelp开启了分页，查询语句会拼接分页操作
		/**
		 *  PageHelper 通过MyBatis的拦截器，向数据库传递SQL语句时，拦截SQL，拼接上分页的limit语句，
		 *  再重新传给数据库
		 *  MyBatis的拦截器是一种AOP思想（面向切面编程）
		 *  AOP通过动态代理实现
		 */
		return new PageInfo<>(list);// 包含分页信息和当前页的数量
	}



	@Override
	public int modifyPwd(String oldPassword, String newPassword, String rePassword,
			Integer id) throws Exception {
		// 1. 参数验证
		if(oldPassword.length()<3 || 
				oldPassword.length()>16) {
			throw new Exception("旧密码必须是3~16位的字符串!");
		}
		if(newPassword.length()<3 || 
				newPassword.length()>16) {
			throw new Exception("新密码必须是3~16位的字符串!");
		}
		if(!newPassword.equals(rePassword)) {
			throw new Exception("两次密码不一致!");
		}
		
		// 2.逻辑
		User user = userMapper.selectById(id);
		String md5Pwd = MD5Util.getMD5(oldPassword);
		if(!user.getPassword().equals(md5Pwd)) {
			throw new Exception("旧密码不正确!");	
		}
		// 新旧密码不能一样
		if(oldPassword.equals(newPassword)) {
			throw new Exception("新旧密码不能一致！");
		}
		
		
		//新密码加密
		user.setPassword(MD5Util.getMD5(newPassword));
		
		//数据库操作修改密码
		return userMapper.update(user);
	}

}
