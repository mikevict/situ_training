package com.situ.taskmgr.controller;

import javax.servlet.http.HttpSession;
import javax.swing.text.LayeredHighlighter;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.situ.taskmgr.entity.Result;
import com.situ.taskmgr.entity.User;
import com.situ.taskmgr.service.UserService;

import ch.qos.logback.core.net.LoginAuthenticator;

/**
 * 
 * @author 王浩
 * 1. 添加@Controller注解，开头的注解，放到spring里，方便用
 * 2. 添加@RequestMapping注解，给当前所有的方法添加映射URL的前缀
 * 3. 添加处理器方法
 * 		1）只负责显示页面GET请求
 * 
 * 		2）负责接受处理POST请求
 */
@Controller
@RequestMapping("/user")
public class UserController {
	@Autowired
	private UserService userService;
	/**
	 * 显示登录页面
	 * 1. 定义一个方法，返回值类型是String类型，返回值是页面的名字
	 * 2. 添加@GetMapping注解,映射URL路径
	 */
	@GetMapping("/login")// 会和类前面的路径拼接在一起，/user/login
	public String login() {
		return "user/login"; 
		// 在templates/user文件夹下应该有一个login.html 	
	}
	/**
	 * 处理登录的操作-用户点击了登录按钮
	 * 1. 定义了一个方法，返回值是String
	 * 		1）参数,接受客户端的数据
	 * 		2）调用了Service层
	 * 		在类中使用@Autowired注解，注入一个Service对象
	 * 		3）根据处理结果，跳转页面
	 * 2.使用@PostMapping注解，添加URL映射,只接受Post操作
	 *  斜杠login是url
	 */
	@PostMapping("/login")
	public String login(User user,// 接受客户端的参数
			HttpSession session, // 保存登录用户的信息
			Model model) {		//传递错误信息
		
		try {
			user = userService.login(user);
			//登录成功
			// 保存登录信息
			session.setAttribute("user", user);
			return "redirect:/";
		}catch (Exception e) {
			e.printStackTrace();
			//登录失败
			//传递错误信息
			model.addAttribute("error",e.getMessage());
			// 返回登陆信息
			return "user/login";
		}
	}
	/**
	 *  退出登录的操作
	 *  打开页面的操作
	 */
	@GetMapping("/logout")
	public String logout(HttpSession session) {
		// 1.清除登录信息
		session.invalidate(); //清除Session对象
		
		// 2.跳转到登录页面
		return "redirect:/user/login";
	}
	
	/**
	 * 打开修改页面的操作
	 */
	@GetMapping("/edit")
	public String edit() {
		return "user/edit";
	}
	
	/**
	 * 修改个人信息的处理-返回JSON格式的数据
	 */
	@PostMapping("/edit")
	@ResponseBody //返回JSON格式的数据
	public Result edit(User user, HttpSession session) {
		if(user.getId()==null) {//修改自己的信息
			// 取出当前登录的用户
			User loginUser = (User) session.getAttribute("user");
			user.setId(loginUser.getId());
			
		}
		
		
		//调用Service层
		try {
			userService.edit(user);
			return Result.success();
		} catch (Exception e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}
	}
	
	/**
	 * 修改密码的页面
	 */
	@GetMapping("/modifyPwd")
	public String modifyPwd() {
		return "user/modifyPwd";
	}
	
	/**
	 * 修改密码的操作
	 */
	@PostMapping("/modifyPwd")
	@ResponseBody
	public Result modifyPwd(String oldPassword, String newPassword,String rePassword,
			HttpSession session) {
		// 取出当前登录的用户
		User user = (User) session.getAttribute("user");
		
		try {
			userService.modifyPwd(oldPassword,newPassword,rePassword,user.getId());
			// 清除登录信息
			session.invalidate();
			return Result.success();
		}catch (Exception e) {
			e.printStackTrace();
			return Result.error(e.getMessage());
		}
	
	}
	
	/**
	 * 员工列表的页面
	 */
	
	@GetMapping("/list")
	public String list() {
		return "user/list";
	}
	
	/**
	 * 获取员工信息
	 */
	@PostMapping("/list")
	@ResponseBody
	public Result list(Integer page,Integer limit) {
		if(page == null) {
			//不分页
			return Result.success(userService.getAll());
		}else {
			return Result.success(userService.getByPage(page, limit));
		}
	}
	
	
	/**
	 * 添加员工的页面
	 */
	@GetMapping("/add")
	public String add() {
		return "user/add";
	}
	
	/**
	 * 添加员工的操作
	 */
	@PostMapping("/add")
	@ResponseBody
	public Result add(User user) {
		try {
			
			userService.add(user);
			// 添加成功
			return Result.success();
		} catch (Exception e) {
			e.printStackTrace();
			// 添加失败
			return Result.error(e.getMessage());
		}
		
	}
	
	
	
	
}
