package com.situ.taskmgr.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import com.situ.taskmgr.interceptor.UserInterceptor;

/**
 * 配置类
 * @author 王浩
 * 1.配置拦截器
 *
 */

@Configuration // 放到Spring容器中,作为一个配置类的对象
public class WebConfig implements WebMvcConfigurer{
	@Autowired
	private UserInterceptor userInterceptor;
	
	/**
	 * 注册拦截器
	 */
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
		registry.addInterceptor(userInterceptor) // 注册拦截器
				.addPathPatterns("/**") 	//指定拦截路径     /**拦截所有路径
				.excludePathPatterns(	//排除不需要拦截的路径
						"/user/login", 	//登录页面必须放行
						"/img/**",		//放行图片
						"/layui/**"		//放行layui
						);		
	}

}
