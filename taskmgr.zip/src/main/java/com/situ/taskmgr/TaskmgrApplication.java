package com.situ.taskmgr;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskmgrApplication {

    public static void main(String[] args) {
        SpringApplication.run(TaskmgrApplication.class, args);
    }

}
