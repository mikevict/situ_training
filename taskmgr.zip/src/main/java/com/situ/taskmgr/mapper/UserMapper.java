package com.situ.taskmgr.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.situ.taskmgr.entity.User;

/**
 * 
 * @author 王浩
 * 1. 添加一个额注解@Mapper,放到容器中直接去取，不用创建对象
 * 2. 添加访问数据库的方法 CURD
 * 3. 为每一个方法添加SQL注解，告诉每一个方法执行的SQL语句是什么
 */

@Mapper
public interface UserMapper {
	/**
	 * 插入用户
	 * 增删改的操作都是返回int
	 * 圆括号字段，花括号去处每一项值
	 */
	@Insert({
		"insert into user",
		"(username,password,phone,email,realname,role)",
		"value(#{username},#{password},#{phone},#{email},#{realname},#{role})",
	})
	int insert(User user);
	
	/**
	 * 修改用户
	 */
	@Update({
		"<script>",// 动态SQL
		"update user",
		"<set>",
		"<if test='password !=null and password.length>0'>password=#{password},</if>",
		"<if test='phone !=null and phone.length>0'>phone=#{phone},</if>",
		"<if test='email !=null and email.length>0'>email=#{email},</if>",
		"<if test='realname !=null and realname.length>0'>realname=#{realname},</if>",
		"<if test='role !=null'>role=#{role},</if>",
		"<if test='status !=null'>status=#{status},</if>",
		"</set>",
		"where id=#{id}",
		"</script>",
	})
	int update(User user);
	
	/**
	 * 查询用户，根据用户名
	 */
	@Select({
		"select * from user",
		"where username = #{username}",
	})
	User selectByUsername(String username);
	
	/**
	 * 查询用户，根据id
	 */
	@Select({
		"select * from user",
		"where id = #{id}"
	})
	User selectById(Integer id);
	/**
	 * 查询所有的用户
	 */
	@Select({
		"select * from user",
	})
	List<User> select();
}
