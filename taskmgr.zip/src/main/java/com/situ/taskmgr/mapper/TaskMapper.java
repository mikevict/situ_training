package com.situ.taskmgr.mapper;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.One;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.situ.taskmgr.entity.Task;

@Mapper
public interface TaskMapper {
	
	
	/**
	 * 添加
	 */
	@Insert({
		"insert into task",
		"(title,content,target,result,start,end,creater_id)",//数据库的字段
		"value",
		"(#{title},#{content},#{target},#{result},#{start},#{end},#{createrId})",//实体类的属性
	})
	@Options(useGeneratedKeys = true,keyColumn = "id",keyProperty = "id")
	//获取数据库自动生成的主键				获取id					保存到task的id属性上
	int insert(Task task);
	
	
	/**
	 * 更新
	 * SQL语句中需要加上逗号
	 */
	@Update({
		"update task",
		"set title=#{title},",
		"content =#{content},",
		"target=#{target},",
		"result=#{result},",
		"start=#{start},",
		"end=#{end},",
		"status=#{status}",
		"where id = #{id}",
	})
	int update(Task task);
	
	/**
	 * 根据ID查询
	 */
	@Select({
		"select * from task",
		"where id = #{id}",
	})
	@Results({
		@Result(column = "id",property = "id",id = true),//映射id列，两个作用，取id，用id来映射查找
		@Result(column = "id",property = "joins",		// 1对多的映射 。select映射方法,映射到joins里
				many = @Many(select = "com.situ.taskmgr.mapper.JoinMapper.selectByTaskId"))
	})
	Task selectById(Integer id);
	
	
	/**
	 * 查询所有
	 */
	
	@Select({
		"select * from task",
	})
	//查完之后，根据creater_id 再调用selectById,方法获取数据，存放到creater中
	// task表关联映射user表，调用了UserMapper中的函数
	@Results({
		@Result(column = "creater_id",property = "createrId"),//关联映射
		@Result(column = "creater_id",property = "creater",
				one=@One(select = "com.situ.taskmgr.mapper.UserMapper.selectById")),
	})
	List<Task> select();
	
	/**
	 * 根据时间查询,查询指定时间之内的任务
	 */
	@Select({
		"select * from task",
		"where",
		"not (end < #{start} or start > #{end})",
	})
	List<Task> selectByDate(@Param("start")Date start,@Param("end")Date end);
}
